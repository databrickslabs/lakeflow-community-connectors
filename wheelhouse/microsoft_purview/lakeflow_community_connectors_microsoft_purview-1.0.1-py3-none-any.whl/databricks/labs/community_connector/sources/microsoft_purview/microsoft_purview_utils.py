"""HTTP, retry, and pagination helpers for the Microsoft Purview connector.

The Unified Catalog Data Governance data-plane API exposes two pagination
models across the endpoints this connector uses:

* **``$skipToken`` continuation** (``/datagovernance/catalog/businessdomains``):
  the response carries an opaque continuation via a ``nextLink`` URL; the
  connector follows ``nextLink`` until it is absent.
* **``skip`` / ``top``** (``/datagovernance/catalog/dataProducts``,
  ``/datagovernance/catalog/terms``): verified live, these return
  ``{value, count}`` and **no** ``nextLink``, so the connector advances
  ``skip`` itself (``skip_top_paginate``). Following only ``nextLink`` here
  reads just the first page and silently truncates at ``top`` records.

Both list shapes wrap records in a ``value`` array. ``next_link_paginate``
handles the ``nextLink`` continuation; ``skip_top_paginate`` handles
``skip``/``top`` (and still follows a ``nextLink`` if one is ever returned).

All requests carry an explicit ``timeout`` and retry on 429/5xx with
exponential backoff (honouring ``Retry-After`` when present).
"""

import time
from typing import Any, Iterator

import requests
from pyspark.sql.types import ArrayType, StructType

from databricks.labs.community_connector.sources.microsoft_purview.microsoft_purview_schemas import (  # pylint: disable=line-too-long
    INITIAL_BACKOFF,
    MAX_RETRIES,
    RETRIABLE_STATUS_CODES,
)

DEFAULT_TIMEOUT = 30  # seconds


def request_with_retry(
    session: requests.Session,
    url: str,
    params: dict[str, str] | None = None,
    timeout: int = DEFAULT_TIMEOUT,
) -> requests.Response:
    """Issue a GET with exponential backoff on retriable status codes.

    Honors the ``Retry-After`` header when present, otherwise doubles the
    backoff (1, 2, 4, 8, 16 s). Always passes an explicit ``timeout``.
    """
    backoff = INITIAL_BACKOFF
    resp = None
    for attempt in range(MAX_RETRIES):
        resp = session.get(url, params=params, timeout=timeout)
        if resp.status_code not in RETRIABLE_STATUS_CODES:
            return resp

        if attempt < MAX_RETRIES - 1:
            retry_after = resp.headers.get("Retry-After")
            try:
                wait = float(retry_after) if retry_after else backoff
            except (TypeError, ValueError):
                wait = backoff
            time.sleep(wait)
            backoff *= 2

    return resp


def api_get(
    session: requests.Session,
    url: str,
    params: dict[str, str] | None,
    label: str,
    timeout: int = DEFAULT_TIMEOUT,
) -> dict:
    """GET and return parsed JSON, raising RuntimeError on non-200 responses."""
    response = request_with_retry(session, url, params, timeout=timeout)
    if response.status_code != 200:
        raise RuntimeError(
            f"Microsoft Purview API error for {label}: "
            f"{response.status_code} {response.text}"
        )
    return response.json()


def next_link_paginate(
    session: requests.Session,
    url: str,
    params: dict[str, str],
    label: str,
    records_key: str = "value",
    *,
    timeout: int = DEFAULT_TIMEOUT,
) -> Iterator[dict[str, Any]]:
    """Yield records from a ``nextLink``-paginated Unified Catalog endpoint.

    The first request uses ``url`` + ``params``; every subsequent page follows
    the absolute ``nextLink`` URL from the previous ``PagedX`` body (which
    already embeds ``api-version``, ``$skipToken``/``skip``, and any filters),
    so ``params`` is only applied to the first call. Stops when ``nextLink`` is
    absent or a page is empty.

    Used for ``businessdomains`` (``$skipToken`` continuation), ``dataProducts``
    and ``terms`` (``skip``/``top``) — all three share the ``{value, nextLink}``
    envelope.
    """
    page_params: dict[str, str] | None = dict(params)
    next_url: str | None = url
    while next_url:
        body = api_get(session, next_url, page_params, label, timeout=timeout)
        batch = body.get(records_key) or []
        yield from batch

        next_url = body.get("nextLink")
        # nextLink is a fully-formed absolute URL; don't re-apply query params.
        page_params = None
        if not batch:
            break


def skip_top_paginate(
    session: requests.Session,
    url: str,
    params: dict[str, str],
    label: str,
    records_key: str = "value",
    *,
    timeout: int = DEFAULT_TIMEOUT,
) -> Iterator[dict[str, Any]]:
    """Yield records from a ``skip`` / ``top`` paginated Unified Catalog endpoint.

    Live behaviour (verified against a Purview tenant): ``dataProducts`` and
    ``terms`` return ``{value, count}`` and **no** ``nextLink`` — the caller
    pages by advancing ``skip``. ``params`` must already carry ``top``.

    * ``skip`` advances by the number of records actually returned (not by
      ``top``), so a server that caps ``top`` below the requested size still
      pages correctly instead of stopping early.
    * Stops on an empty page, or once ``skip`` reaches ``count`` when the
      response reports it.
    * If a response ever does carry a ``nextLink``, it is followed instead
      (it already embeds ``skip``/``top``), so the helper works with either
      continuation shape.
    * Guard: if a page repeats the previous page's first record (a server
      ignoring ``skip``), stop rather than loop forever re-reading it.
    """
    skip = 0
    prev_first_id: Any = None
    next_url: str | None = None
    while True:
        if next_url:
            body = api_get(session, next_url, None, label, timeout=timeout)
        else:
            page_params = dict(params)
            page_params["skip"] = str(skip)
            body = api_get(session, url, page_params, label, timeout=timeout)

        batch = body.get(records_key) or []
        if not batch:
            return
        first_id = batch[0].get("id") if isinstance(batch[0], dict) else None
        if first_id is not None and first_id == prev_first_id:
            return
        prev_first_id = first_id

        yield from batch
        skip += len(batch)

        next_url = body.get("nextLink") or None
        if next_url:
            continue
        count = body.get("count")
        if isinstance(count, int) and skip >= count:
            return


def empty_structs_to_none(record: dict[str, Any], schema: Any) -> dict[str, Any]:
    """Replace empty objects in struct-typed fields with None, per ``schema``.

    Purview can return ``{}`` for an object field with nothing in it (seen:
    ``additionalProperties`` on a data product with no data assets). The
    framework rejects an empty dict for a StructType ("field in StructType
    cannot be an empty dict"), which aborts the whole pipeline, so these become
    None. Walks nested structs and arrays of structs; fields not in the record
    are left alone.
    """
    for field in schema.fields:
        if field.name in record:
            record[field.name] = _clean_struct_value(record[field.name], field.dataType)
    return record


def _clean_struct_value(value: Any, data_type: Any) -> Any:
    if isinstance(data_type, StructType):
        if not isinstance(value, dict):
            return value
        if not value:
            return None
        return {
            k: (_clean_struct_value(v, data_type[k].dataType) if k in data_type.names else v)
            for k, v in value.items()
        }
    if isinstance(data_type, ArrayType) and isinstance(value, list):
        return [_clean_struct_value(v, data_type.elementType) for v in value]
    return value


def normalize_contacts(value: Any) -> dict[str, Any] | None:
    """Normalize a ``ContactsMap`` to the declared struct shape.

    Keeps only the declared roles (``owner`` / ``expert`` / ``databaseAdmin``)
    and coerces each contact to ``{id, description}`` so unexpected API keys
    don't break schema coercion. Returns ``None`` for an absent/empty map so
    the field maps cleanly onto the nullable struct.
    """
    if not isinstance(value, dict) or not value:
        return None
    out: dict[str, Any] = {}
    for role in ("owner", "expert", "databaseAdmin"):
        entries = value.get(role)
        if isinstance(entries, list):
            out[role] = [
                {"id": c.get("id"), "description": c.get("description")}
                for c in entries
                if isinstance(c, dict)
            ]
        else:
            out[role] = None
    return out
